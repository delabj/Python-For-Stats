# -*- coding: utf-8 -*-
"""
Created on Sun Nov 24 23:31:41 2019
@author: haritima
In this script we will learn about commenting and section breaks
"""

#%%

""" 
Multi
    line 
    comment 
"""

'''
Multi
line 
comment 
'''
#Single line comment

#%% Section break 